﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SagasDemo.Events
{
    public interface IOrderProcessed:IMessage
    {
    }
}
