﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SagasDemo.Commands
{
    public interface IProcessPayment: IMessage
    {
    }
}
