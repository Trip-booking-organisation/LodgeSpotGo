﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SagasDemo
{
    [Serializable]
    public class Customer
    {
        public string Name { get; set; }
    }
}
